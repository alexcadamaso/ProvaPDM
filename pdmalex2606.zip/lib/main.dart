import 'package:flutter/material.dart';
import 'package:pdm2606/aula_componentes.dart';

void main() {
  runApp(AulaComponentes());
}
