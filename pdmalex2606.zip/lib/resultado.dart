import 'package:flutter/material.dart';

class Resultado extends StatelessWidget {
  final List<String> respostasSelecionadas;

  Resultado({required this.respostasSelecionadas});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Respostas selecionadas:',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: respostasSelecionadas
                .map((resposta) => Text('- $resposta'))
                .toList(),
          ),
          SizedBox(height: 20),
          Text(
            'Questionário terminado!',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}
