package com.example.pdm2606

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
